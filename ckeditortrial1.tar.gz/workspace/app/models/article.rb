class Article < ActiveRecord::Base
end
